<?php


?>
<h4>Password reset complete</h4>
<p>You may now login using your new password.</p>
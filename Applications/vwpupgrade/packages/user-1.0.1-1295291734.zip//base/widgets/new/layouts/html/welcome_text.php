<?php
 
// Text Email

$this->email->subject = "Welcome to " . $this->site_name;

?>
Welcome to <?php echo $this->site_name; ?>!

This email is being sent to you as a courtesy to notify you that someone signed up for an account with us at <?php echo $this->site_url; ?> using this email address. If you believe that you are receiving this email in error please reply to this email with your concerns.

-- Management

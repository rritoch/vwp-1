<?php

?><vdoc:include alias="content" /><?php 

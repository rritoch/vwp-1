<?php

?>
<user_login>
 <new_user href="index.php?app=user&amp;widget=new" />
 <remind href="index.php?app=user&amp;widget=remind" />
</user_login> 
 
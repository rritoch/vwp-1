<?php

 /**
  * WSDL Document
  */

echo $this->wsdl;   

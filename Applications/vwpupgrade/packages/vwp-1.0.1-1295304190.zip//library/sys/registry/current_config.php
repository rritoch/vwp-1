<?php

/**
 * VWP Registry Library
 * 
 * This file provides the CURRENT_CONFIG registry key.
 *   
 * @package VWP
 * @subpackage Libraries.System
 * @author Ralph Ritoch <rritoch@gmail.com>
 * @copyright (c) Ralph Ritoch - All Rights Reserved
 * @link http://www.vnetpublishing.com VNetPublishing.Com
 * @license http://www.vnetpublishing.com/Legal/Licenses/2010/10/vnetlpl.txt VNETLPL Limited Public License
 * @todo Implement HKEY_CURRENT_CONFIG Registry key
 */

/**
 * VWP Registry Library
 * 
 * This is the class for a CURRENT_CONFIG registry key.
 *   
 * @package VWP
 * @subpackage Libraries.System
 * @author Ralph Ritoch <rritoch@gmail.com>
 * @copyright (c) Ralph Ritoch - All Rights Reserved
 * @link http://www.vnetpublishing.com VNetPublishing.Com
 * @license http://www.vnetpublishing.com/Legal/Licenses/2010/10/vnetlpl.txt VNETLPL Limited Public License
 */
 
 class HKEY_CURRENT_CONFIG extends HKEY 
 {
 
 }
 
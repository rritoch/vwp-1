<content>
 <content_title>Content Example!</content_title>
 <message>Edit me at: /themes/site/default/apps/content/home/xml/default.php</message>
</content>
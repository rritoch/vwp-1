<?php 

/**
 * VWP - Default tabs footer layout
 * 
 * @package    VWP
 * @subpackage Layouts.Tabs
 * @author Ralph Ritoch <rritoch@gmail.com>
 * @link http://www.vnetpublishing.com VNetPublishing.Com 
 * @copyright (c) Ralph Ritoch - All rights reserved
 * @license http://www.vnetpublishing.com/Legal/Licenses/2010/10/vnetlpl.txt VNETLPL Limited Public License   
 */


?></div></div></div></div>
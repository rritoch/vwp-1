
var tinyMCEImageList = new Array(
	// Name, URL
);

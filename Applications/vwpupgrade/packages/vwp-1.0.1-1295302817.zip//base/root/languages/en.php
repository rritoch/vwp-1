<?php

VWP::RequireLibrary('vwp.language.language');

 class enLanguage extends VLanguage {
 
   
 }

<?php


?>
<div class="article">
<h4 class="title"><?php echo htmlentities($this->article["title"]); ?></h4>
<?php echo $this->article["content"]; ?>
</div>
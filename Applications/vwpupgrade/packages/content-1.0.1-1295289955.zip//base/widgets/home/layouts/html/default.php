<?php

// No direct access

class_exists( 'VWP' ) or die( 'Restricted access' );

echo $this->index; // display index
<?php

 class content_Model_Content extends VModel {
  
  function getTitle() {
   return "VNet Publishing - Web Applications and Content Writing";
  }
 
 }

?>
<?php


class VXSLT extends VObject {

    public static function translate($srcDoc,$xsltDoc) {
        $proc = new XSLTProcessor();
        $proc->importStylesheet($xsltDoc);        
        $t = $proc->transformToXML($srcDoc);        
        $tdoc = new DomDocument;
        $tdoc->loadXML($t);
        return $tdoc;                
    }

}


<?php

VWP::RequireLibrary('vwp.net');
VNet::RequireClient('http');

class VXMLHelper extends VObject {

    public static function sameNamespace($ns1,$ns2) {    
        return rtrim($ns1,'/') == rtrim($ns2,'/');
    }
        
    public static function getPrefixList($node) {
        $prefixList = array();
        
        $tagName = $node->nodeName;
        $parts = explode(':',$tagName);
        if (count($parts) > 1) {
         array_pop($parts);
         $prefix = implode(':',$parts);
         $prefixList[$prefix] = true;
        }
        
        for($i=0; $i < $node->attributes->length; $i++) {
            $attrib = $node->attributes->item($i);
            $tagName = $node->nodeName;
                        
            $parts = explode(':',$tagName);
            if (count($parts) > 1) {
             array_pop($parts);
             $prefix = implode(':',$parts);
             $prefixList[$prefix] = true;
            }
        }
        
        for($i=0; $i < $node->childNodes->length; $i++) {
            $childNode = $node->childNodes->item($i);
            if ($childNode->nodeType == XML_ELEMENT_NODE) {
                $childPrefixes = self::getPrefixList($childNode);
                foreach($childPrefixes as $prefix) {
                    $prefixList[$prefix] = true;
                }            
            }
        }
                                        
        return array_keys($prefixList);
    }
    
    /**
     * Encode string to XML data
     * 
     *  @param string $txt Source text
     * @return string Encoded text
     * @access public
     */
              
    public static function xmlentities($txt) {
       $str = $txt;
       $str = str_replace("&","&amp;",$str);
       $str = str_replace("<","&lt;",$str);
       $str = str_replace(">","&gt;",$str);
       $str = str_replace("\"","&quot;",$str);
       return $str;  
    }
    
    
    public static function fetch($url) {
    
        if (v()->filesystem()->path()->isAbsolute($url)) {
            $src = v()->filesystem()->file()->read($url);   
        } else {
            $httpClient =& VHTTPClient::getInstance();
            $src = $httpClient->wget($url);
        }

        if (VWP::isWarning($src)) {
            return $src;
        }
                            
        $doc = new DomDocument;
        VWP::noWarn(true);
        $r = $doc->loadXML($src);
        VWP::noWarn(false);
        if (!$r) {
            return VWP::raiseWarning("Invalid document received from $url.",'VXMLHelper::fetch',null,true);
        }
        return $doc;    
    }  
  
}
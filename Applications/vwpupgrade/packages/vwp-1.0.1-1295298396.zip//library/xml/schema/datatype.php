<?php

class VSchema_DataType extends VObject {

    public $id = null;
    public $name = null;
    public $namespace = null;
    public $schemaNode = null;
    

    function __construct($schemaNode = null,$targetNamespace = null) {
        
        if (!empty($schemaNode)) {
            $this->schemaNode = $schemaNode;        
            $name = $schemaNode->getAttribute('name');            
            $parts = explode(':',$name);        
            $name = array();        
            $this->name = array_pop($parts);
            $prefix = implode(':',$parts);
            $this->namespace = empty($prefix) ? $targetNamespace : $schemaNode->lookupNamespaceURI($prefix);
            $this->id = $this->namespace . '#types.' . $this->name;
        }
    }
}

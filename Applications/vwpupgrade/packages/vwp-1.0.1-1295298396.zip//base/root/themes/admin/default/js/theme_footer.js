/**
 * Javascript Cleanup
 */
  
cleanAllControls();